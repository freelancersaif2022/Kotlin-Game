package example
import com.badlogic.gdx.ApplicationAdapter
import com.badlogic.gdx.Gdx
import com.badlogic.gdx.assets.AssetManager
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.g2d.Animation
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.g2d.TextureAtlas
import com.badlogic.gdx.graphics.g2d.TextureRegion
import com.badlogic.gdx.utils.Array
import com.badlogic.gdx.utils.viewport.FitViewport

class AnimationExample : ApplicationAdapter() {
    private val assets = AssetManager()
    private lateinit var batch: SpriteBatch
    private lateinit var run: Animation<TextureRegion>
    private val viewport = FitViewport(1280f, 720f)
    private var time = 0f
    override fun create() {
        batch = SpriteBatch()
        assets.load("atlases/characters.atlas", TextureAtlas::class.java)
        assets.finishLoading()
        val atlas = assets.get("atlases/characters.atlas", TextureAtlas::class.java)
        val frames = Array<TextureRegion>()
        for (i in 0 until 10) {
            frames.add(requireNotNull(atlas.findRegion("characters/max/running/${i.toString().padStart(2, '0')}")))
        }
        run = Animation(1f / 15f, frames, Animation.PlayMode.LOOP)
    }
    override fun resize(width: Int, height: Int) { viewport.update(width, height, true) }
    override fun render() {
        time += Gdx.graphics.deltaTime
        Gdx.gl.glClearColor(0.08f, 0.12f, 0.2f, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT)
        viewport.apply()
        batch.projectionMatrix = viewport.camera.combined
        batch.begin()
        batch.draw(run.getKeyFrame(time), 420f, 100f)
        batch.end()
    }
    override fun dispose() { batch.dispose(); assets.dispose() }
}

# Bramble Dash — Kotlin + LibGDX asset pack

Actual indexed PNG sprites and eight LibGDX TextureAtlas files. Put the contents of this folder in your LibGDX assets directory. Keep atlas pages beside their .atlas files. See kotlin_examples/AnimationExample.kt. Load only the active character/world groups to manage GPU memory. PNG compressed size is not GPU memory usage: each 2048 RGBA page occupies 16 MiB without mipmaps.

## Scope and quality

This is a development asset pack, not verified AAA production art. All requested named cast members, animation sequence names, worlds, 30 obstacle names, power-ups, collectibles, UI component families and VFX categories are represented. Important quality and motion requirements remain incomplete:

- Character, enemy and boss sequences are cutout deformation of single generated poses, not individually drawn limb animation. Run cycles do not provide a complete natural alternating leg gait; combat, victory and death poses need artist refinement.
- Environment art, UI, obstacles, items and VFX are deterministic raster illustrations, simpler than the generated character art; AAA/commercial visual consistency is not certified.
- UI includes reusable screen panels and controls, not assembled functional screens. Runtime text, fonts, layout, navigation, sound and gameplay code are outside this asset pack.
- Collision boxes are automatically derived AABB suggestions, not hand-tuned gameplay or attack hitboxes.
- Seam edge equality is validated; the entire parallax composition and motion still require in-game visual review.
- Some obstacle families share construction and several item icon families share symbols; this is not a fully bespoke art set.
- LibGDX atlas syntax and coordinates are statically checked; Kotlin example has not been compiled or tested on Android.
- No audio assets are included (not requested). No independent AAA quality certification or originality/legal clearance is claimed.

## Metadata

metadata/sprites.json contains exact atlas page, top-left pixel rectangle, local bottom-left pivot and logical folder for every region. metadata/animations.json lists ordered frame region names, seconds per frame and looping. All actors share a fixed canvas per category; draw relative to the supplied pivot. Collision AABBs vary by pose and must be tuned. Do not use VFX or UI collision suggestions as colliders; their enabled flag is false.

Folders contain regions.json indexes instead of duplicate PNGs. extract_sprites.py optionally exports individual sprites with Pillow. Sprite name lookup uses the complete region path; index is -1. This avoids TextureAtlas.findRegions sorting ambiguity. Build Animation<TextureRegion> using the metadata frame order.

## Environments and UI

Worlds provide four 1280×720 parallax layers, 256×128 ground/platform/decoration/lighting regions. Edge columns match. Suggested parallax speeds: 0.08, 0.25, 0.5, 0.8. Render two adjacent copies and wrap in world coordinates. Repeat cropped TextureRegions by drawing them; GL_REPEAT repeats the whole atlas page and is unsuitable here. Screen panels are blank layout surfaces with headings; populate them with controls and runtime values. UI text labels use DejaVu Sans Bold rasterized into PNGs. Raw panel.9.png is a source nine-patch; for LibGDX construct NinePatch from the interior 64×64 region with 22px splits, or repack through TexturePacker with nine-patch support. Do not render the marker border as normal image content.

## Provenance

Character source artwork: built-in image generation, stylized-concept prompts for a five-runner source sheet, ten-enemy source sheet and five-boss source sheet. Alpha component extraction preserves separate silhouettes. Sequences are derived by squashing, rotation, translation and row-wise cutout deformation. Supporting raster assets are algorithmically drawn. No external artwork was downloaded. No audio or third-party texture packs are included.

See metadata/manifest.json and metadata/validation.json for measured counts and automated checks. Human animation polish and Android testing remain necessary.

"""Optional: pip install pillow; python extract_sprites.py OUTPUT_DIRECTORY"""
from pathlib import Path
import json,sys
from PIL import Image
root=Path(__file__).parent; dest=Path(sys.argv[1]); cache={}
for name,s in json.loads((root/'metadata/sprites.json').read_text()).items():
    page=s['page']
    if page not in cache:cache[page]=Image.open(root/page)
    x,y=s['xy'];w,h=s['size'];p=dest/(name+'.png');p.parent.mkdir(parents=True,exist_ok=True)
    cache[page].crop((x,y,x+w,y+h)).save(p)
